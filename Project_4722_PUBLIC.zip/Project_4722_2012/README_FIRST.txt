PROJECT 4722
Local copy recovered from an old folder
----------------------------------------

If you found this folder, start with:
  01_START\FRAGMENT_001.jpg
  01_START\note_4722.txt

Keep a paper notebook. Write down every filename, checksum, and result.
Some clues are in the contents of files; others depend on how the files are stored.

Trail so far: 4722 -> TR4722 -> steganography -> KEEWATIN -> public geography -> Lenovo N21 -> LROJ -> INDEX -> more transforms -> final cache.

Everything needed for the main chain is included here, apart from ordinary public reference research. No visits, private-person searches, account access, or full device serial numbers are part of this puzzle. The machine clue is only the public fragment LROJ.

NOTE ABOUT THE IMAGE: OutGuess is a real historical tool, but the hidden payload supplied in this folder is in a PNG using red-channel least-significant bits. It is not an OutGuess-generated JPEG. That distinction matters.

Use SHA256SUMS.txt to check that files have not changed.
