fragment 002 - file format notes

The previous answer points to steganography and the name OutGuess. OutGuess is a real historical steganography tool, but this artifact is intentionally NOT an OutGuess-generated JPEG: it is a PNG containing a real least-significant-bit (LSB) payload. The distinction is part of the investigation. Do not claim you ran OutGuess on this PNG.

Investigate the file type and pixels. Recover a null-terminated ASCII message by reading the least significant bit of each pixel's red channel, in row-major order, most-significant bit first per byte. Stop at the first zero byte. The first recovered word is the next answer.

You can inspect this with a short script or any tool that exposes raw pixel data. This is actual hidden data in the supplied image, not a button that reveals the answer.
