#!/usr/bin/env python3
"""Decode Project 4722's actual red-channel LSB payload. Requires Pillow."""
from PIL import Image
import sys
path = sys.argv[1] if len(sys.argv) > 1 else '../02_STEGO/field_image.png'
im = Image.open(path).convert('RGB')
out = bytearray(); bits = []
for r, g, b in im.getdata():
    bits.append(r & 1)
    if len(bits) == 8:
        value = 0
        for bit in bits: value = (value << 1) | bit
        if value == 0: break
        out.append(value); bits.clear()
print(out.decode('ascii'))
